import { Html, Loader } from "@react-three/drei";

export const Loading = () => {
	return (
		<Html>
			<Loader />
		</Html>
	);
};
