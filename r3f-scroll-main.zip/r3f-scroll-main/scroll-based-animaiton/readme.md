# Air Not So Jordans

# React-3-Fiber, GSAP, Three js,

<img align="left" alt="three js" width="30px" style="padding-right:10px;" src="https://global.discourse-cdn.com/standard17/uploads/threejs/original/2X/e/e4f86d2200d2d35c30f7b1494e96b9595ebc2751.png" />

<img align="left" alt="GSAP" width="30px" style="padding-right:10px;" src="https://cdn.worldvectorlogo.com/logos/gsap-greensock.svg" />

<img align="left" alt="react" width="30px" style="padding-right:10px;" src="https://www.vectorlogo.zone/logos/reactjs/reactjs-icon.svg" />

<img align="left" alt="TypeScript" width="30px" style="padding-right:10px;" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-plain.svg" />

<br/>
<br/>

[Live Demo](https://r3f-scroll-three.vercel.app/)

Project created to learn gsap in react three fiber for scroll based animation

## YT Video
[![Learn React Three Fiber + GSAP: Create Stunning 3D Animations for the Web](https://ytcards.demolab.com/?id=_qzuECf1h2w&title=Learn+React+Three+Fiber+%2B+GSAP%3A+Create+Stunning+3D+Animations+for+the+Web&lang=en&timestamp=1678996810&background_color=%230d1117&title_color=%23ffffff&stats_color=%23dedede&width=250 "Learn React Three Fiber + GSAP: Create Stunning 3D Animations for the Web")](https://www.youtube.com/watch?v=_qzuECf1h2w)

<img width="1662" alt="Screenshot 2023-03-05 at 12 42 57 PM" src="https://user-images.githubusercontent.com/76642519/222950730-214ca861-db1b-4913-a87d-aa0188261bac.png">

<img width="1662" alt="Screenshot 2023-03-05 at 12 43 31 PM" src="https://user-images.githubusercontent.com/76642519/222950733-528dbb84-e4ae-47a4-8ab8-0a1dd98744c3.png">

<img width="1664" alt="Screenshot 2023-03-05 at 12 43 49 PM" src="https://user-images.githubusercontent.com/76642519/222950736-a433c3cb-01d4-4fb1-a09d-1aa187e41aa5.png">


# Skills Acquired

-   GSAP
